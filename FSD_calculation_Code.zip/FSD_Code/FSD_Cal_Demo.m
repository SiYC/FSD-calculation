% This is a demo for calculating FSD using the fun FSD_Compare
% Code written by Siyuan Chen
% Updated March 2022 for matlab release R2020a

%% Main section

% GT     = imread('Path_Name\File_Name.tif') % Ground Truth image here
% SEG    = imread('Path_Name\File_Name.tif') % Segmentation image here

% Res    = 2
% Method = 'SEG';
% GT_Truncated_Thresh = [50, 2000];
% SEG_Truncated_Thresh = [50, 2000];
% [stats_GT, stats_SEG] = FSD_Compare(GT,SEG,Res,Method,GT_Trunc_Range,SEG_Trunc_Range); 

[stats_GT, stats_SEG] = FSD_Compare; % GT              - Ground Truth
                                     % SEG             - Segmented binary image
                                     %                   (data type available: .jpg, .jpeg, .bmp, .png, .tif
                                     %                   new data type can be added in line 26 and 32 in FSD_Compare)
                                     % Res             - Pixel size in meter
                                     % Method          - Name of the segmentation method to be shown in the legend
                                     %                   (default = 'SEG')
                                     % GT_Trunc_Range  - Truncation Range of the LSF fitting for GT
                                     % SEG_Trunc_Range - Truncation Range of the LSF fitting for SEG
                                                                                     
%% Code below is for you to amend or save the CND plots with LSF predictive line
% For GT plot

% Specify the truncation range here
GT_Trunc_Range = [50, 2000];

% Plot CND
figure, 
FSD_GT = loglog(stats_GT(:,1),stats_GT(:,2));
xlabel('Mean Caliper Diameter (m)','FontWeight','Bold','FontSize',20)
ylabel('Cumulative floe numbers (km^-2)','FontWeight','Bold','FontSize',20)
% title('Add title here','FontWeight','Bold','FontSize',24)
ylim([0.01 1000])
xlim([1 100000])
set(FSD_GT, {'DisplayName'}, {'GT'}')
grid on
set(gcf,'unit','centimeters','position',[10 5 30 25])
hold on

% Generate Truncated line
ForFit_GT = [];
ForFit_GT = stats_GT(find(stats_GT(:,1) > GT_Trunc_Range(1) ,1,'first'): find(stats_GT(:,1) < GT_Trunc_Range(2) ,1,'last'),:);
GT_Trunc_Range = [ForFit_GT(1,1), ForFit_GT(end,1)];
xline(GT_Trunc_Range(1),'--');
xline(GT_Trunc_Range(2),'--');

% Determine the exponent Alpha
Poly_GT = polyfit(log10(ForFit_GT(:,1)), log10(ForFit_GT(:,2)), 1);
LSF_GT  = polyval(Poly_GT, log10(ForFit_GT(:,1)));
LSF_GT2 = 10.^(LSF_GT);

% Plot the predictive line
legend(FSD_GT,'FontSize',24,'Location','northeast')
plot(ForFit_GT(:,1), LSF_GT2, '-r', 'DisplayName', 'GT fitting');
text(ForFit_GT(1,1) * 2, LSF_GT2(1), strcat('α =', num2str(-Poly_GT(1))), 'Interpreter', 'none','Color','red','FontSize',20);

% Save the plot
saveas(gcf,'PathName\FileName.tif');

%% For SEG plot

% Specify the truncation range here
SEG_Trunc_Range = [50, 2000];

% Plot CND
figure, 
FSD_SEG = loglog(stats_GT(:,1),stats_GT(:,2),stats_SEG(:,1),stats_SEG(:,2));
xlabel('Mean Caliper Diameter (m)','FontWeight','Bold','FontSize',20)
ylabel('Cumulative floe numbers (km^-2)','FontWeight','Bold','FontSize',20)
% title('Add title here','FontWeight','Bold','FontSize',24)
ylim([0.01 1000])
xlim([1 100000])
set(FSD_SEG, {'DisplayName'}, {'GT Esiber', Method}')
grid on
set(gcf,'unit','centimeters','position',[10 5 30 25])
hold on

% Generate Truncated line
ForFit_SEG = [];
ForFit_SEG = stats_SEG(find(stats_SEG(:,1) > SEG_Trunc_Range(1) ,1,'first'): find(stats_SEG(:,1) < SEG_Trunc_Range(2) ,1,'last'),:);
SEG_Trunc_Range = [ForFit_SEG(1,1), ForFit_SEG(end,1)];
xline(SEG_Trunc_Range(1),'--');
xline(SEG_Trunc_Range(2),'--');

% Determine the exponent Alpha
Poly_SEG = polyfit(log10(ForFit_SEG(:,1)), log10(ForFit_SEG(:,2)), 1);
LSF_SEG = polyval(Poly_SEG, log10(ForFit_SEG(:,1)));
LSF_SEG2 = 10.^(LSF_SEG);

% Plot the predictive line
legend(FSD_SEG,'FontSize',24,'Location','northeast')
plot(ForFit_SEG(:,1), LSF_SEG2, '-','Color','#77AC30', 'DisplayName', 'Predicted fitting');
text(ForFit_SEG(1,1) * 2, LSF_SEG2(1), strcat('α =', num2str(-Poly_SEG(1))), 'Interpreter', 'none','Color','#77AC30','FontSize',20);

% Save the plot
saveas(gcf,'PathName\FileName.tif');

