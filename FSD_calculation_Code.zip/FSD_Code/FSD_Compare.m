% ////////////////////////////////////////////////////////////////////////
% This function caculates the Mean Caliper Diameter and Cumulative floe 
% Number Density (FCD). The definations can be refered to the paper: 
% Hwang, B., et al., "A practical algorithm for the retrieval of floe size
% distribution of Arctic sea ice from high-resolution satellite Synthetic
% Aperture Radar imagery" Elementa: Science of the Anthropocene, 2017. 5
% 
% Input:
%       GT              - Ground Truth binary image
%       SEG             - Segmentation result, also binary image
%       Res             - Pixel size in meter
%       Method          - Name to show in the legend, string type, default:'SEG'
%       GT_Trunc_Range  - Truncation Range of the LSF fitting for GT
%       SEG_Trunc_Range - Truncation Range of the LSF fitting for SEG
% Output:
%       stats_GT        - N by 2 matrix where Colum 1 is Mean Caliper
%                         Diameter(m), Colum 2 is Cumulative floe numbers(km^-2)
%       stats_SEG       - N by 2 matrix where Colum 1 is Mean Caliper
%                         Diameter(m), Colum 2 is Cumulative floe numbers(km^-2)
%       
% Code written by Siyuan Chen
% Updated March 2022 for matlab release R2020a
% ////////////////////////////////////////////////////////////////////////

function [stats_GT, stats_SEG] = FSD_Compare(GT,SEG,Res,Method,GT_Trunc_Range,SEG_Trunc_Range)

if nargin < 4
    % Select images if not exist or empty
    if ~exist('GT','var') || isempty(GT)
        [GT_FileName,  GT_PathName] = uigetfile( '*.jpg;*.jpeg;*.bmp;*.png;*.tif', ...
                                       'Select GT data');
        if ~GT_FileName, warning('No GT data'); return; end
        GT = imread( strcat(GT_PathName, GT_FileName) );
    end
    if ~exist('SEG','var') || isempty(SEG)
        [SEG_FileName, SEG_PathName]  = uigetfile( '*.jpg;*.jpeg;*.bmp;*.png;*.tif', ...
                                       'Select SEG data');
        if ~SEG_FileName, warning('No SEG data'); return; end
        SEG  = imread( strcat(SEG_PathName, SEG_FileName) );
    end
    % Res
    if ~exist('Res','var') || isempty(Res)
        prompt = 'Please enter the pixel size(meter):';
        Res = input(prompt);
    end
    % Method (default = 'SEG')
    if ~exist('Method','var') || isempty(Method)
        Method = 'SEG';
    end
end
% Ensure SEG and GT are in the same data type
SEG = logical(SEG);
GT  = logical(GT);
% Check if SEG and GT match
[Row_1, Col_1, numberOfColorBands_1] = size (GT);
[Row_2, Col_2, numberOfColorBands_2] = size (SEG);
if numberOfColorBands_1 > 1
    warning('GT is not in BW')
    return;
end
if numberOfColorBands_2 > 1
    warning('SEG is not in BW')
    return;
end
if (Row_1 ~= Row_2) || (Col_1 ~= Col_2)
    warning('GT and SEG do not match')
    return;
end

% Calculate the Area in km^2
km2 = Row_1 * Col_1 * Res^2 * 1e-6;

STATS_GT  = regionprops(bwlabel(GT),'MaxFeretProperties','MinFeretProperties');
STATS_SEG = regionprops(bwlabel(SEG),'MaxFeretProperties','MinFeretProperties');
hMaxVal   = length(STATS_GT)+length(STATS_SEG);

h = waitbar(0,'Calculating CND...');
set(h,'Name','CND plot generation');

% ------------------- for GT ----------------------------------------
% Calculate Mean Caliper Diameter(MCD) in pixel-level
for i = 1:length(STATS_GT)
    GT_MCD(i,1) = 0.5 * (STATS_GT(i).MaxFeretDiameter + STATS_GT(i).MinFeretDiameter);
end

% Record MCD
GT_MCD_Unique = unique(GT_MCD);
FSD_Measure_GT = zeros(length(GT_MCD_Unique),2);
FSD_Measure_GT(:,1) = GT_MCD_Unique(:,1);

% Record frequency
for i = 1:length(STATS_GT)
    for ii = 1:length(GT_MCD_Unique)
        if GT_MCD(i) == GT_MCD_Unique(ii)
            FSD_Measure_GT(ii,2) = FSD_Measure_GT(ii,2) + 1;
        end
    end
    waitbar(i/hMaxVal);
end

% Unit Transformation
FSD_UnitTR_GT = zeros(length(GT_MCD_Unique),2);
FSD_UnitTR_GT(:,1) = FSD_Measure_GT(:,1) * Res;  % MCD in Meter
FSD_UnitTR_GT(:,2) = FSD_Measure_GT(:,2) / km2;  % Density in times per Km^2 
CumSum_GT = FSD_UnitTR_GT(:,2);
CumSum_GT = cumsum(CumSum_GT,1,'reverse');       % Cumulative Density
FSD_UnitTR_GT(:,2) = CumSum_GT(:);
% Output
stats_GT = FSD_UnitTR_GT;


% ------------------- for SEG ----------------------------------------
for i = 1:length(STATS_SEG)
    SEG_MCD(i,1) = 0.5 * (STATS_SEG(i).MaxFeretDiameter + STATS_SEG(i).MinFeretDiameter);
end

% Record MCD
SEG_MCD_Unique = unique(SEG_MCD);
FSD_Measure_SEG = zeros(length(SEG_MCD_Unique),2);
FSD_Measure_SEG(:,1) = SEG_MCD_Unique(:,1);

% Record frequency
for i = 1:length(STATS_SEG)
    for ii = 1:length(SEG_MCD_Unique)
        if SEG_MCD(i) == SEG_MCD_Unique(ii)
            FSD_Measure_SEG(ii,2) = FSD_Measure_SEG(ii,2) + 1;
        end
    end
    waitbar((length(STATS_GT)+i)/hMaxVal);
end 
close(h)

% Unit TR
FSD_UnitTR_SEG = zeros(length(SEG_MCD_Unique),2);
FSD_UnitTR_SEG(:,1) = FSD_Measure_SEG(:,1) * Res;
FSD_UnitTR_SEG(:,2) = FSD_Measure_SEG(:,2) / km2;
CumSum_SEG = FSD_UnitTR_SEG(:,2);
CumSum_SEG = cumsum(CumSum_SEG,1,'reverse');
FSD_UnitTR_SEG(:,2) = CumSum_SEG(:);
stats_SEG = FSD_UnitTR_SEG;

% ------------------- Plot ----------------------------------------

% Floe Number Comparison
FloeNum_BarCompare(SEG,GT,Method)

% Plot CND
CND_SEG_GT(stats_GT, stats_SEG, Method)

% (GT)  CND with LSF fitting line and Alpha
if ~exist('GT_Truncated_Thresh','var') || isempty(GT_Trunc_Range)
    disp('Truncation range for GT need to be specified')
    prompt_L = 'Please enter the smallest value for truncation:';
    GT_L = input(prompt_L);
    prompt_R = 'Please enter the largest value for truncation:';
    GT_R = input(prompt_R);
    GT_Trunc_Range = [GT_L, GT_R];
end
GT_CND_LSF_Fitting(stats_GT, GT_Trunc_Range)

% (SEG) CND with LSF fitting line and Alpha
    % Specify the truncation thresholds here
if ~exist('SEG_Truncated_Thresh','var') || isempty(SEG_Trunc_Range)
    disp('Truncation range for SEG need to be specified')
    disp('Do you want to use the same range as GT?')
    prompt = 'Enter 1 or 2 (1-Yes, 2-No):';
    same = input(prompt);
    if same == 1
        SEG_Trunc_Range = GT_Trunc_Range;
    elseif same == 2
        prompt_L = 'Please enter the smallest value for truncation:';
        GT_L = input(prompt_L);
        prompt_R = 'Please enter the largest value for truncation:';
        GT_R = input(prompt_R);
        SEG_Trunc_Range = [GT_L, GT_R];
    end
end
SEG_CND_LSF_Fitting(stats_GT, stats_SEG, SEG_Trunc_Range, Method)

end


function CND_SEG_GT(stats_GT, stats_SEG, Method)
figure, 
FSD_Plot = loglog(stats_GT(:,1),stats_GT(:,2),stats_SEG(:,1),stats_SEG(:,2));
xlabel('Mean Caliper Diameter (m)','FontWeight','Bold','FontSize',20)
ylabel('Cumulative floe numbers (km^-2)','FontWeight','Bold','FontSize',20)
ylim([0.01 10000])
xlim([1 100000])
set(FSD_Plot, {'DisplayName'}, {'GT',Method}')
legend('FontSize',24,'Location','northeast')
grid on
set(gcf,'unit','centimeters','position',[10 5 30 25])

end



function FloeNum_BarCompare(SEG,GT,Method)

    for k = 1:2
        if k == 1
            labeledImage = bwlabel(SEG);
        else
            labeledImage = bwlabel(GT);
        end
        
        ImageStats = regionprops(labeledImage, 'Area');
        numberOfBlobs = size(ImageStats, 1);

        floe_area = cat(1, ImageStats.Area);
        FSD.E1 = 0;FSD.E2 = 0;FSD.E3 = 0;FSD.E4 = 0;FSD.E5 = 0;FSD.E6 = 0;FSD.E7 = 0;FSD.E8 = 0;FSD.E9 = 0;FSD.ERR=0;

        for i = 1:numberOfBlobs
            if floe_area(i) <= 1e1
                FSD.E1 = FSD.E1+1;
            elseif floe_area(i) > 1e1 && floe_area(i) <= 1e2
                FSD.E2 = FSD.E2+1;
            elseif floe_area(i) > 1e2 && floe_area(i) <= 1e3  
                FSD.E3 = FSD.E3+1;
            elseif floe_area(i) > 1e3 && floe_area(i) <= 1e4  
                FSD.E4 = FSD.E4+1;
            elseif floe_area(i) > 1e4 && floe_area(i) <= 1e5  
                FSD.E5 = FSD.E5+1;
            elseif floe_area(i) > 1e5 && floe_area(i) <= 1e6  
                FSD.E6 = FSD.E6+1;
            elseif floe_area(i) > 1e6 && floe_area(i) <= 1e7  
                FSD.E7 = FSD.E7+1;
            elseif floe_area(i) > 1e7 && floe_area(i) <= 1e8  
                FSD.E8 = FSD.E8+1;
            elseif floe_area(i) > 1e8 && floe_area(i) <= 1e9  
                FSD.E9 = FSD.E9+1;
            else
                FSD.ERR = FSD.ERR + 1;
            end
        end
        if FSD.ERR ~= 0
            error('Single floe larger than 10^9 pixel');
        end

        if k == 1
            FSD.SEG(1,1:9) = [FSD.E1 FSD.E2 FSD.E3 FSD.E4 FSD.E5 FSD.E6 FSD.E7 FSD.E8 FSD.E9];
        else
            FSD.GT(1,1:9) = [FSD.E1 FSD.E2 FSD.E3 FSD.E4 FSD.E5 FSD.E6 FSD.E7 FSD.E8 FSD.E9];
        end   
    end
    
%     PCC = (sum( (FSD.SEG-mean(FSD.SEG)).*(FSD.GT-mean(FSD.GT)) )) / ( (sqrt(sum((FSD.SEG-mean(FSD.SEG)).^2)))*(sqrt(sum((FSD.GT-mean(FSD.GT)).^2))) );  

    FSD.X = categorical({'10^1','10^2','10^3','10^4','10^5','10^6','10^7','10^8','10^9'});
    FSD.X = reordercats(FSD.X,{'10^1','10^2','10^3','10^4','10^5','10^6','10^7','10^8','10^9'});
    % For GT
    FSD.Y(1,1:9) = FSD.GT;
    % For SEG
    FSD.Y(2,1:9) = FSD.SEG;

    figure
    h = bar(FSD.X,FSD.Y,'grouped');
    xlabel('Floe size (number of pixels per floe)','FontWeight','Bold','FontSize',20)
    ylabel('Frequency','FontWeight','Bold','FontSize',20)

    set(h, {'DisplayName'}, {'GT',Method}')
    legend('FontSize',24,'Location','northeast')
    set(gcf,'unit','centimeters','position',[5 5 25 15])
    grid on

    
end

function GT_CND_LSF_Fitting(stats_GT, GT_Trunc_Range)
    % GT FSD plot with Least-Square Fit (LSF) predictive line

    % Plot CND
    figure, 
    FSD_GT = loglog(stats_GT(:,1),stats_GT(:,2));
    xlabel('Mean Caliper Diameter (m)','FontWeight','Bold','FontSize',20)
    ylabel('Cumulative floe numbers (km^-2)','FontWeight','Bold','FontSize',20)
    % title('Add title here','FontWeight','Bold','FontSize',24)
    ylim([0.01 1000])
    xlim([1 100000])
    set(FSD_GT, {'DisplayName'}, {'GT'}')
    grid on
    set(gcf,'unit','centimeters','position',[10 5 30 25])
    hold on

    % Generate Truncated line
    ForFit_GT = [];
    ForFit_GT = stats_GT(find(stats_GT(:,1) > GT_Trunc_Range(1) ,1,'first'): find(stats_GT(:,1) < GT_Trunc_Range(2) ,1,'last'),:);
    GT_Trunc_Range = [ForFit_GT(1,1), ForFit_GT(end,1)];
    xline(GT_Trunc_Range(1),'--');
    xline(GT_Trunc_Range(2),'--');

    % Determine the exponent Alpha
    Poly_GT = polyfit(log10(ForFit_GT(:,1)), log10(ForFit_GT(:,2)), 1);
    LSF_GT  = polyval(Poly_GT, log10(ForFit_GT(:,1)));
    LSF_GT2 = 10.^(LSF_GT);

    % Plot the predictive line
    legend(FSD_GT,'FontSize',24,'Location','northeast')
    plot(ForFit_GT(:,1), LSF_GT2, '-r', 'DisplayName', 'Predictive line');
    text(ForFit_GT(1,1) * 2, LSF_GT2(1), strcat('α =', num2str(-Poly_GT(1))), 'Interpreter', 'none','Color','red','FontSize',20);
end

function SEG_CND_LSF_Fitting(stats_GT, stats_SEG, SEG_Trunc_Range, Method)
    % SEG FSD plot with Least-Square Fit (LSF) predictive line

    % Plot CND
    figure, 
    FSD_SEG = loglog(stats_GT(:,1),stats_GT(:,2),stats_SEG(:,1),stats_SEG(:,2));
    xlabel('Mean Caliper Diameter (m)','FontWeight','Bold','FontSize',20)
    ylabel('Cumulative floe numbers (km^-2)','FontWeight','Bold','FontSize',20)
    % title('Add title here','FontWeight','Bold','FontSize',24)
    ylim([0.01 1000])
    xlim([1 100000])
    set(FSD_SEG, {'DisplayName'}, {'GT Esiber', Method}')
    grid on
    set(gcf,'unit','centimeters','position',[10 5 30 25])
    hold on

    % Generate Truncated line
    ForFit_SEG = [];
    ForFit_SEG = stats_SEG(find(stats_SEG(:,1) > SEG_Trunc_Range(1) ,1,'first'): find(stats_SEG(:,1) < SEG_Trunc_Range(2) ,1,'last'),:);
    SEG_Trunc_Range = [ForFit_SEG(1,1), ForFit_SEG(end,1)];
    xline(SEG_Trunc_Range(1),'--');
    xline(SEG_Trunc_Range(2),'--');

    % Determine the exponent Alpha
    Poly_SEG = polyfit(log10(ForFit_SEG(:,1)), log10(ForFit_SEG(:,2)), 1);
    LSF_SEG = polyval(Poly_SEG, log10(ForFit_SEG(:,1)));
    LSF_SEG2 = 10.^(LSF_SEG);

    % Plot the predictive line
    legend(FSD_SEG,'FontSize',24,'Location','northeast')
    plot(ForFit_SEG(:,1), LSF_SEG2, '-','Color','#77AC30', 'DisplayName', 'Predictive line');
    text(ForFit_SEG(1,1) * 2, LSF_SEG2(1), strcat('α =', num2str(-Poly_SEG(1))), 'Interpreter', 'none','Color','#77AC30','FontSize',20);
end
